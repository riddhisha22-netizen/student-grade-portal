# Student Grade Portal

A Flask-based student grade portal. Upload an Excel `.xlsx` class marksheet to calculate totals, percentages, grades and pass/fail results, view class statistics and charts, print individual report cards, and download results.

## Project structure

```text
student_grade_portal/
├── app.py
├── student_grade_calculator.py
├── sample_students.xlsx
├── requirements.txt
├── render.yaml
├── README.md
├── .gitignore
├── static/
│   └── style.css
└── templates/
    ├── base.html
    ├── index.html
    ├── results.html
    ├── report.html
    └── error.html
```

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:5000`.

## Excel format

The workbook needs these columns: `RollNo`, `Name`, `English`, `Maths`, `Science`, `Computer`, and `Hindi`. Title rows above the header row are allowed. Existing Total, Percentage, Grade and Result columns are recalculated.

## Notes

- Results are stored in memory and are cleared when the server restarts.
- The upload limit is 5 MB.
- Keep `student_grade_calculator.py` in the same folder as `app.py`.
